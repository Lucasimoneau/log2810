package Tp1;


public class Main {

    public static void main(String[] args) {
        /*
        Tester test = new Tester();
        if(test.nodeTest()) System.out.println( "READNODE WORKS");
        else System.out.println("eww");
        if(test.graphTest()) System.out.println("graph created successfully");
        if(test.djikstraTester()) System.out.println("DJIKSTRA WORKS");
         */
        UserInterface ui = new UserInterface();
        ui.run();
    }

}
